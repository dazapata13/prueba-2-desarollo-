/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package veiculos_electricos;

import java.util.Scanner;

/**
 *
 * @author Cetecom
 */
public class Veiculos_Electricos {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner entrada = new Scanner (System.in);
        
        int opcion = 0 ;
        
        while (opcion != 5){
            System.out.println("menu");
            System.out.println("opcion 1");
            System.out.println("opcion 2 ");
            System.out.println("opcion 3 ");
            System.out.println("opcion 4 ");
            
            
            opcion = entrada.nextInt();
            
            switch (opcion){
                case 1:
                    System.out.println("opcion 1");
                    break;
            }
        
            
            switch (opcion){
                case 2: 
                    System.out.println("opcion 2");
                    break;
            }
        
            switch (opcion){
                case 3: 
                    System.out.println("opcion 3 ");
                    break;
            }
            
            switch (opcion){
                case 4:
                    System.out.println("opcion 4 ");
                    break;
            }
            
            
            
            
            
            
            
            
            
        }
  
 
 
      

        
        // TODO code application logic here
    }
    
}
